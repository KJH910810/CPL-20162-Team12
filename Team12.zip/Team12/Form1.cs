﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Team12
{
    public partial class Sheet : Form
    {
        public Sheet()
        {
            InitializeComponent();
        }

        private void plotToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void chart1_Click(object sender, EventArgs e)
        {

        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            try
            {

                string Chosen_File = "";

                OpenFileDialog openFD = new OpenFileDialog();
                openFD.Filter = "Excel Files | *.xlsx, *.xls, *.xlsm|Text Files|*.txt|Word Documents|*.doc";

                if (openFD.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    Chosen_File = openFD.FileName;
                    this.textPath.Text = openFD.FileName;
                    richTextBox1.LoadFile(Chosen_File, RichTextBoxStreamType.PlainText);
                }

                string constr = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + textPath.Text + ";Extended Properties=\"Excel 12.0;HDR=Yes\";";
                OleDbConnection con = new OleDbConnection(constr);
                con.Open();

                dropdown_sheet.DataSource = con.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                dropdown_sheet.DisplayMember = "TABLE_NAME";
                dropdown_sheet.ValueMember = "TABLE_NAME";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnLoadExcel_Click(object sender, EventArgs e)
        {
            try
            {
                string constr = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + textPath.Text + ";Extended Properties = \"Excel 12.0; HDR=YES;\";";
                OleDbConnection con = new OleDbConnection(constr);
                OleDbDataAdapter sda = new OleDbDataAdapter("Select employee_name, email_address, contact From [" + dropdown_sheet.SelectedValue + "]", con);
                DataTable dt = new DataTable();
                sda.Fill(dt);

                foreach (DataRow row in dt.Rows)
                {
                    dataGridView1.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {

        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            string Saved_File = "";

            saveFD.InitialDirectory = "C:";
            saveFD.Title = "Save a Text File";
            saveFD.FileName = "";

            saveFD.Filter = "Text Files|*.txt|All Files|*.*";

            if (saveFD.ShowDialog() != DialogResult.Cancel)
            {
                Saved_File = saveFD.FileName;
                richTextBox1.SaveFile(Saved_File, RichTextBoxStreamType.PlainText);
            }

        }

        private void undoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (richTextBox1.CanUndo == true)
            {
                richTextBox1.Undo();
            }
        }

        private void copyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (richTextBox1.SelectionLength > 0) // 드래그 범위가 존재시에
            {
                richTextBox1.Copy();
            }
        }

        private void pasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Clipboard.GetDataObject().GetDataPresent(DataFormats.Text) == true) //????
            {
                richTextBox1.Paste();
            }
        }

        private void cutToolStripMenuItem_Click(object sender, EventArgs e)
        {

            if (richTextBox1.SelectedText != "")
            {
                richTextBox1.Cut();
            } // 선택범위 잘라내기
        }

        private void redoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Redo();
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {

                string Chosen_File = "";

                OpenFileDialog openFD = new OpenFileDialog();
                openFD.Filter = "Excel Files | *.xlsx, *.xls, *.xlsm|Text Files|*.txt|Word Documents|*.doc";

                if (openFD.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    Chosen_File = openFD.FileName;
                    this.textPath.Text = openFD.FileName;
                    richTextBox1.LoadFile(Chosen_File, RichTextBoxStreamType.PlainText);
                }

                string constr = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + textPath.Text + ";Extended Properties=\"Excel 12.0;HDR=Yes\";";
                OleDbConnection con = new OleDbConnection(constr);
                con.Open();

                dropdown_sheet.DataSource = con.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                dropdown_sheet.DisplayMember = "TABLE_NAME";
                dropdown_sheet.ValueMember = "TABLE_NAME";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string Saved_File = "";

            saveFD.InitialDirectory = "C:";
            saveFD.Title = "Save a Text File";
            saveFD.FileName = "";

            saveFD.Filter = "Text Files|*.txt|All Files|*.*";

            if (saveFD.ShowDialog() != DialogResult.Cancel)
            {
                Saved_File = saveFD.FileName;
                richTextBox1.SaveFile(Saved_File, RichTextBoxStreamType.PlainText);
            }
        }

        private void quitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Really Quit?", "Exit", MessageBoxButtons.OKCancel) == DialogResult.OK)
            {
                Application.Exit();
            }
        }

        private void toolStripButton11_Click(object sender, EventArgs e)
        {

        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            if (richTextBox1.CanUndo == true)
            {
                richTextBox1.Undo();
            }
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            richTextBox1.Redo();
        }

        private void toolStripButton6_Click(object sender, EventArgs e)
        {
            if (richTextBox1.SelectionLength > 0) // 드래그 범위가 존재시에
            {
                richTextBox1.Copy();
            }
        }

        private void toolStripButton7_Click(object sender, EventArgs e)
        {
            if (Clipboard.GetDataObject().GetDataPresent(DataFormats.Text) == true) //????
            {
                richTextBox1.Paste();
            }
        }

        private void toolStripButton8_Click(object sender, EventArgs e)
        {
            if (richTextBox1.SelectedText != "")
            {
                richTextBox1.Cut();
            } // 선택범위 잘라내기
        }
    }
}
